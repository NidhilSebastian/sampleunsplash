export const HomeInitialState = {
    imageList:[],
    isLoggedIn: false,
    count:0
  };

  export const AppInitialState = {
    user: sessionStorage.getItem("user")
  };

  
  