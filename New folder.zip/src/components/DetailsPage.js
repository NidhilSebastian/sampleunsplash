import React, { Component } from 'react'

export class DetailsPage extends Component {
    render() {
        return (
            <div>
                Details page
            </div>
        )
    }
}

export default DetailsPage
